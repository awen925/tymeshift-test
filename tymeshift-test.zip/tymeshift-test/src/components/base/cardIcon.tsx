import styled from '@emotion/styled';
import { IconBase } from './iconBase';

export const CardIcon = styled(IconBase)`
  margin-right: 8px;
`;
