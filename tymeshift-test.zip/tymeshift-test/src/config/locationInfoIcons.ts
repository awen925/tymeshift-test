import Users from '../assets/icons/users.svg';
import Timezone from '../assets/icons/timezone.svg';
import Views from '../assets/icons/views.svg';

export const LocationInfoIcons = { Users, Timezone, Views };
