import { PageError } from '../../components/base/pageError';

export default PageError;
